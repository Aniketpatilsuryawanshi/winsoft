/*
Name: Jayshri Ramnath Hagawane
Q4:Write a Java Program to find the duplicate characters in a string
*/

import java.util.HashMap;

public class DuplicateChar
 {
    public static void findDuplicateCharacters(String str) {
        
        HashMap<Character, Integer> charFrequencyMap = new HashMap<>();

        str = str.toLowerCase();

        for (char ch : str.toCharArray()) {
            if (Character.isLetter(ch))
				{ 
                charFrequencyMap.put(ch, charFrequencyMap.getOrDefault(ch, 0) + 1);
            }
        }

 
        System.out.println("Duplicate characters in the string:");
        for (char ch : charFrequencyMap.keySet()) {
            if (charFrequencyMap.get(ch) > 1) {
                System.out.println(ch + " - " + charFrequencyMap.get(ch) + " times");
            }
        }
    }

    public static void main(String[] args) {
        String inputString = "Hello World";

        findDuplicateCharacters(inputString);
    }
}
