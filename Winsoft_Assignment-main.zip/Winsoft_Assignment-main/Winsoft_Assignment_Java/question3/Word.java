/*
Name: Jayshri Ramnath Hagawane
 
Q3:Write a Java Program to count the number of words in a string using HashMap.*/

import java.util.HashMap;

class Word
{
    public static HashMap<String, Integer> countWords(String str) 
	{
        HashMap<String, Integer> wordCountMap = new HashMap<>();
        
        String[] words = str.split("\\s+");

        for (String word : words) 
		{

            word = word.replaceAll("[^a-zA-Z]", "").toLowerCase();
            wordCountMap.put(word, wordCountMap.getOrDefault(word, 0) + 1);
        }

        return wordCountMap;
    }

    public static void main(String[] args) {
        String inputString = "Hello, Myself Jayshri Ramnath Hagawane, I am currently pursuing the Bachelor of Engineering from Sandip Institute of Engineering and Management";

        HashMap<String, Integer> wordCounts = countWords(inputString);

        System.out.println("Word Counts:");
        for (String word : wordCounts.keySet())
			{
				System.out.println(word + ": " + wordCounts.get(word));
            }
    }
}
