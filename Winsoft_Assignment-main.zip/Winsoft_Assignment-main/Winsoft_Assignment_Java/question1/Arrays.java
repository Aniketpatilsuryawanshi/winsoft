//Name:Jayshri Ramnath Hagawane

/*Q1:Mergetwoarraysbysatisfyinggivenconstraints
GiventwosortedarraysX[]andY[]ofsizem andneachwherem >=nandX[]hasexactlyn
vacantcells,
mergeelementsofY[]intheircorrectpositioninarrayX[],i.e.,merge(X,Y)bykeepingthesorted
order.*/


class Arrays {
    public static void merge(int[] X, int[] Y) {
        int m = X.length;
        int n = Y.length;

        int i = m - 1; 
        int j = n - 1; 
        int k = m + n - 1; 

        while (i >= 0 && j >= 0)
			{
            if (X[i] > Y[j]) 
			{
                X[k--] = X[i--];
            } 
			else 
			{
                X[k--] = Y[j--];
            }
        }

        while (j >= 0) {
            X[k--] = Y[j--];
        }
    }

    public static void main(String[] args) {
        int[] X = { 0,2,0, 3,0, 5, 6,0,0};
        int[] Y = {1, 8, 9, 10, 15};

        merge(X, Y);

        for (int num : X) {
            System.out.print(num + " ");
        }
    }
}
